package sn.iam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sn.iam.agile.entity.Projet;
import sn.iam.agile.repository.ProjetRepository;
import sn.iam.exception.ProjetException;

@Service
public class ProjetService {
	@Autowired
	private ProjetRepository projetRepository;
	
	public Projet saveOrUpdate(Projet projet) {
		try {
			projet.setCode(projet.getCode().toUpperCase());
			return projetRepository.save(projet);
		}catch (Exception e) {
			throw new ProjetException("Code Projet :" +projet.getCode().toUpperCase()+" existe deja !!!");
		}
	}
	

}
