package sn.iam.agile.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import sn.iam.agile.entity.Projet;

@Repository
public interface ProjetRepository extends CrudRepository<Projet, Long>{
	Projet findByCode(String code);

}
