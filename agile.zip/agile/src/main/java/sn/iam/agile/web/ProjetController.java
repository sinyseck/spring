package sn.iam.agile.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sn.iam.agile.entity.Projet;
import sn.iam.agile.repository.ProjetRepository;

@RestController
@RequestMapping("/api/projet")
public class ProjetController {
	
	//Injecter le repo dans le controlleur
	@Autowired
	private ProjetRepository projetRepository;
	//creation d'un projet
	@PostMapping("/add")
	public ResponseEntity<Projet> createNewProjet(@RequestBody Projet p){
		Projet projet = projetRepository.save(p);
		return new ResponseEntity<Projet>(projet, HttpStatus.CREATED);
	}
	//methode pour lister
	@GetMapping("/liste")
	public ResponseEntity<List<Projet>> listeProjet()
	{
		List<Projet> listProjet = (List<Projet>) projetRepository.findAll();
		return new ResponseEntity<>(listProjet,HttpStatus.OK);
	}
	
	

}
