package sn.iam.agile.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sn.iam.agile.entity.Projet;
import sn.iam.agile.repository.ProjetRepository;

@RestController
@RequestMapping("/api/projet")
public class ProjetController {
	
	//Injecter le repo dans le controlleur
	@Autowired
	private ProjetRepository projetRepository;
	//creation d'un projet
	@PostMapping("/add")
	public ResponseEntity<?> createNewProjet(@RequestBody Projet p){
		if(p.getDateFin().after(p.getDateDebut()))
		{
			Projet projet = projetRepository.save(p);
			return new ResponseEntity<Projet>(projet, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<>("Echec d'insertion", HttpStatus.BAD_REQUEST);

		}
	}
	//methode pour lister
	@GetMapping("/liste")
	public ResponseEntity<List<Projet>> listeProjet()
	{
		List<Projet> listProjet = (List<Projet>) projetRepository.findAll();
		return new ResponseEntity<>(listProjet,HttpStatus.OK);
	}
	
	//methode pour rechercher un projet par son code: find projet by id
	@GetMapping("/{code}")
	public ResponseEntity<?> getProjetByCode(@PathVariable String code)
	{
		Projet projet = projetRepository.findByCode(code);
		return new ResponseEntity<>(projet,HttpStatus.OK);

	}
	
	//methode pour supprimer un projet
		@DeleteMapping("/{code}")
		public ResponseEntity<?> deleteProjet(@PathVariable String code) 
		{
			Projet projet = projetRepository.findByCode(code);
			projetRepository.delete(projet);
			return new ResponseEntity<>("suppression reussie",HttpStatus.OK);

			
		}
}
